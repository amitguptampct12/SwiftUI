//
//  DogFactsApp.swift
//  DogFacts
//
//  Created by Amit Gupta on 14/12/24.
//

import SwiftUI

@main
struct DisneyCharactersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
