//
//  APIConstants.swift
//  DogFacts
//
//  Created by Amit Gupta on 14/12/24.
//

/* Disney APIs*/
let getCharacterAPI = "https://api.disneyapi.dev/character"
