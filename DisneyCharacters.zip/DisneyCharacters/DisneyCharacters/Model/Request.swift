//
//  Request.swift
//  DogFacts
//
//  Created by Amit Gupta on 14/12/24.
//
import Foundation

struct Request : Encodable {
    
}
